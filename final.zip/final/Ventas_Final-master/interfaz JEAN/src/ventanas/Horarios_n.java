/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import Datos.DCitas;
import Logico.LCitas_n;
import java.awt.Graphics;
import java.awt.PrintJob;
import java.awt.TextField;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author alumnos
 */
public class Horarios_n extends javax.swing.JFrame {
    LCitas_n citas= new LCitas_n();
    DCitas d=new DCitas();
    Logico.Conexion c = new Logico.Conexion();
    PreparedStatement cmd;  
    ResultSet rs;
    String busqueda;
    public static String dato;
    public Horarios_n() {
        PreparedStatement cmd;  
        ResultSet rs;
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("ASENUT - Historial Nutricional");
        this.setIconImage(new ImageIcon(getClass().getResource("/imagenes/logoASENUTbarra.PNG")).getImage());
       
        
    }

    private void CargarTabla(){
        try {
            DefaultTableModel modelo;
            LCitas_n func=new LCitas_n();
            modelo =func.CargarTabla();
            Lista_Cita.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    private void busquedapornombre(String buscar){
        try {
            DefaultTableModel modelo;
            LCitas_n func=new LCitas_n();
            modelo =func.buscarpornombre(buscar);
            Lista_Cita.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    private void busquedaporfechas(String fecha,String fecha1){
        try {
            DefaultTableModel modelo;
            LCitas_n func=new LCitas_n();
            modelo =func.buscarporfecha(fecha, fecha1);
            Lista_Cita.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    private void busquedacompleta(String nombre,String fecha,String fecha1){
        try {
            DefaultTableModel modelo;
            LCitas_n func=new LCitas_n();
            modelo =func.buscarcompleto(nombre, fecha, fecha1);
            Lista_Cita.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Lista_Cita = new javax.swing.JTable();
        btnBuscar = new javax.swing.JButton();
        txtfBuscar = new javax.swing.JTextField();
        txtFecha1 = new com.toedter.calendar.JDateChooser();
        txtFecha = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnImprimir = new javax.swing.JMenu();
        btnEditar = new javax.swing.JMenu();
        btnActualizar = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Lista_Cita.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "COD Horario", "Nom pac", "Ape pac", "Telefono", "Hora Cita", "Fecha Cita"
            }
        ));
        jScrollPane1.setViewportView(Lista_Cita);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 660, 150));

        btnBuscar.setText("Buscar");
        btnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBuscarMouseClicked(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, -1, -1));

        txtfBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(txtfBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 210, -1));
        getContentPane().add(txtFecha1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 130, -1));
        getContentPane().add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, 130, -1));

        jLabel2.setText("HASTA");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 10, -1, -1));

        jLabel3.setText("DESDE");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574_1.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jLabel1.setPreferredSize(new java.awt.Dimension(720, 260));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 220));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnImprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Imprimir.png"))); // NOI18N
        btnImprimir.setText("Imprirmir");
        btnImprimir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnImprimirMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnImprimir);

        btnEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Edit.png"))); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEditarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnEditar);

        btnActualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Update.png"))); // NOI18N
        btnActualizar.setText("Actualizar");
        btnActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnActualizarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnActualizar);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu5.setText("Regresar");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu5);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/minimize-icon-17_2.png"))); // NOI18N
        jMenu1.setText("Minimizar");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu5MouseClicked
        // TODO add your handling code here:
        Citas c = new Citas();
        c.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu5MouseClicked
    
    private void btnEditarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditarMouseClicked
        // TODO add your handling code here:
        dato=String.valueOf(Lista_Cita.getValueAt(Lista_Cita.getSelectedRow(),0));
        EditarHorario eh=new EditarHorario();
        eh.setVisible(true);
        this.dispose();
   
    }//GEN-LAST:event_btnEditarMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
       CargarTabla();
    }//GEN-LAST:event_formWindowOpened

    private void btnBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseClicked
        if( txtFecha.getDate()==null && txtFecha1.getDate()==null && txtfBuscar.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ingrese un parametro para la busqueda","Error!",JOptionPane.ERROR_MESSAGE);
        }else if(txtfBuscar.getText().isEmpty()){
            int anio = txtFecha.getCalendar().get( Calendar.YEAR );
            int mes = txtFecha.getCalendar().get( Calendar.MONTH );
            int dia = txtFecha.getCalendar().get( Calendar.DAY_OF_MONTH );
            String fecha = anio+"-"+(mes+1)+"-"+dia;
            int anio1 = txtFecha1.getCalendar().get( Calendar.YEAR );
            int mes1 = txtFecha1.getCalendar().get( Calendar.MONTH );
            int dia1= txtFecha1.getCalendar().get( Calendar.DAY_OF_MONTH );
            String fecha1 = anio1+"-"+(mes1+1)+"-"+dia1;
            busquedaporfechas(fecha,fecha1);
            
        }else if(txtFecha.getDate()==null && txtFecha1.getDate()==null){
            busqueda=txtfBuscar.getText();
            busquedapornombre(busqueda);
        }else{
            busqueda=txtfBuscar.getText();
            int anio = txtFecha.getCalendar().get( Calendar.YEAR );
            int mes = txtFecha.getCalendar().get( Calendar.MONTH );
            int dia = txtFecha.getCalendar().get( Calendar.DAY_OF_MONTH );
            String fecha = anio+"-"+(mes+1)+"-"+dia;
            int anio1 = txtFecha1.getCalendar().get( Calendar.YEAR );
            int mes1 = txtFecha1.getCalendar().get( Calendar.MONTH );
            int dia1= txtFecha1.getCalendar().get( Calendar.DAY_OF_MONTH );
            String fecha1 = anio1+"-"+(mes1+1)+"-"+dia1;
            busquedacompleta(busqueda,fecha,fecha1);
        }
        
    }//GEN-LAST:event_btnBuscarMouseClicked

    private void btnActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnActualizarMouseClicked
        CargarTabla();
    
    }//GEN-LAST:event_btnActualizarMouseClicked

    private void txtfBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfBuscarActionPerformed

    private void btnImprimirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnImprimirMouseClicked
        PrintJob imprime = getToolkit().getPrintJob(this, evt.getClass().getName(), null);
        if (imprime != null) {
            Graphics pag = imprime.getGraphics();
            if (pag != null) {
                paint(pag); //pinta todo los objetos de la ventana mostrada
                pag.dispose();
            }
        } else {
            //JOptionPane.showMessageDialog(null, “no se imprimo nada”, “imprimir”, JOptionPane.INFORMATION_MESSAGE );
            imprime.end();
        }
        imprime.end();        // TODO add your handling code here:
    }//GEN-LAST:event_btnImprimirMouseClicked

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_jMenu1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Horarios_n.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Horarios_n.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Horarios_n.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Horarios_n.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Horarios_n().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Lista_Cita;
    private javax.swing.JMenu btnActualizar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JMenu btnEditar;
    private javax.swing.JMenu btnImprimir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private com.toedter.calendar.JDateChooser txtFecha;
    private com.toedter.calendar.JDateChooser txtFecha1;
    private javax.swing.JTextField txtfBuscar;
    // End of variables declaration//GEN-END:variables
}
